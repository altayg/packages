# ganet
Global Assessment of NETwork Inference Algorithms Based on the Available Literature of Gene/Protein Interactions

All the details of this software can be seen in the following publication:
http://journals.tubitak.gov.tr/biology/issues/biy-13-37-5/biy-37-5-6-1210-8.pdf
